# resume-template
Angular Resume template for developers

Angular 8:

https://update.angular.io/#7.0:8.0

npm install -g typescript@">=3.4.0 <3.5.0"
npm install typescript@">=3.4.0 <3.5.0"  --save-dev --save-exact

https://stackoverflow.com/a/56186570/704681
